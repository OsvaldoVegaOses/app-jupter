# Diario de Reflexividad

Este documento propone la estructura para un diario de reflexividad versionado (git) que acompa�e cada sprint de an�lisis cualitativo.

## Prop�sito
- Registrar supuestos, sesgos, decisiones metodol�gicas y cambios en criterios de codificaci�n.
- Dejar trazabilidad de rotaci�n de credenciales, ajustes t�cnicos y validaciones de calidad de datos.
- Facilitar auditor�as internas y la reproducci�n del proceso.

## Estructura Recomendada
Mant�n una entrada por sesi�n de trabajo usando el siguiente bloque Markdown:

```
## YYYY-MM-DD - Nombre / Rol
### Contexto
- Objetivo de la sesi�n.
- Materiales analizados (entrevistas, fragmentos, scripts).

### Observaciones
- Dudas sobre fidelidad de transcripci�n.
- Notas sobre sesgos personales o del equipo.
- Incidencias t�cnicas (errores, tiempos de respuesta de APIs, drift de embeddings).

### Decisiones Tomadas
- Ajustes en unidad de an�lisis o criterios de inclusi�n/exclusi�n.
- Cambios en cat�logos (�reas tem�ticas, actores, banderas booleanas).
- Acciones sobre credenciales o configuraciones (.env, rotaciones).

### Pr�ximos Pasos
- Tareas pendientes.
- Validaciones requeridas (health checks, revisiones cruzadas).
```

## Buenas Pr�cticas
- Versionar el diario dentro de `docs/reflexividad.md` o dividirlo por semana (`docs/reflexividad/2025-W45.md`).
- Usar commits espec�ficos del diario (`chore(reflexividad): entrada 2025-10-30`).
- Referenciar issues o tareas del backlog cuando corresponda.
- Adjuntar capturas o hashes (colocar en almacenamiento seguro) cuando se eval�en fragmentos sensibles.

## Integraci�n con el Pipeline
- Al finalizar cada ingesta (`python main.py � ingest`), agregar nota con el lote de archivos y hash del commit de configuraci�n.
- Si se detecta drift de dimensiones (`len(vector) != EMBED_DIMS`), documentar la incidencia, el despliegue afectado y la acci�n correctiva.
- Registrar pruebas de `scripts/healthcheck.py` y su resultado (verde/rojo) para mantener evidencia de gobernanza de datos.

Mantener este diario es clave para asegurar reflexividad constante y cumplir con los est�ndares de investigaci�n cualitativa rigurosa.
