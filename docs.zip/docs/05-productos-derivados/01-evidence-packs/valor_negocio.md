# Valor de negocio (Evidence Packs)

## Usuario objetivo
- Consultoras (estrategia/CX/EX/reputación)
- ONG/filantropía/evaluación de impacto
- Sector público (diagnósticos con evidencia)

## Promesa
Acelerar la entrega de insights **defendibles**: cada conclusión tiene evidencia rastreable y un manifest para auditoría.

## Diferenciador
"AI + metodología + trazabilidad" empaquetado como entregable cliente-ready.
