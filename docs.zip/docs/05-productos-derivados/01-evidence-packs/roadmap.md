# Roadmap (Evidence Packs)

## P0
- Definir plantillas mínimas de entregable (informe + anexos + manifest)
- Definir políticas de anonimización y campos obligatorios de trazabilidad

## P1
- “Evidence packs” por categoría/tema con ranking y cobertura
- Export adicional (docx/pdf vía pipeline)

## P2
- Flujo de revisión/aprobación (versionado de entregables)
- Métricas de QA (cobertura, saturación, sesgo)
