# Roadmap (Interoperabilidad CAQDAS)

## P0
- Documentar mapeo mínimo: códigos, citas-texto, fragmentos, memos
- Definir conjunto de pruebas de exportación (proyectos ejemplo)

## P1
- Completar NVivo/ATLAS.ti (según requerimientos reales de import)
- Validación automática de paquetes

## P2
- Export incremental y compatibilidad multi-proyecto
- Guías por herramienta (paso a paso)
