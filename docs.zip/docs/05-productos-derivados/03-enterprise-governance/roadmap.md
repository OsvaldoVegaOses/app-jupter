# Roadmap (Enterprise Governance)

## P0
- Definir eventos mínimos de auditoría y política de retención
- Definir alcance SSO/OAuth (proveedores, roles)

## P1
- Especificación de controles (export, delete, administración)
- Evidencias para auditoría (procedimientos + logs)

## P2
- Hardenings y guías on-prem
- Evaluación formal de compliance (externa)
