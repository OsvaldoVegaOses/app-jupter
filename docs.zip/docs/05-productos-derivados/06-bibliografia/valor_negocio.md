# Valor de negocio (App Bibliográfica)

## Usuario objetivo
- Investigadores (academia/centros de estudio)
- Equipos de policy/research en gobierno
- Consultoras que requieren marcos teóricos trazables

## Promesa
Reducir tiempo y aumentar calidad del marco teórico, manteniendo referencias formales y evidencia auditable por obra.

## Diferenciador
Síntesis asistida por IA con trazabilidad fina (obra→ubicación→evidencia).
