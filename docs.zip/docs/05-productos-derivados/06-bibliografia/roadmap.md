# Roadmap (App Bibliográfica)

## P0
- Entidad de obra + ingesta reproducible (PDF/HTML)
- Extracción y normalización mínima de referencias

## P1
- Resolución DOI + deduplicación
- Export BibTeX/CSL-JSON

## P2
- Detección de in-text citations y mapeo a referencias
- QA de cobertura (años/temas/fuentes)
